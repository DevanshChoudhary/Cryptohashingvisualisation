                                                         Enigma_learner   
---------------------------------------------------------------------------------------------------------------------------------
As an aspiring developer,
Everyone needs to learn the techniques of encryption, to add a layer of security to their application. During our research and learning stage me and the team never found that "ONE GO-TO PLACE" to learn cryptography from scratch to advanced in a simplified way.

in short, this project explains the algorithm by using a user-entered example

----------------------------------------------------------------------------------------------------------------------------------
  
--> have a look on image.PNG file  
--> import the folder enigmalearner by eclipse  
--> if issue persist while importing directly copy classes and images to the project folder according to the image.PNG file  
--> run welcome.java

------------------------------------------------------------------------------------------------------------------------------------

--> While using this project do give credits  
--> If having any problem with this code feel free to mail me at "singhdevendra818@gmail.com"

------------------------------------------------------------------------------------------------------------------------------------

							Snippets

![Picture1](https://github.com/enigmaOfficial/enigma_learner/blob/master/Snipps/Picture1.png)
![Picture2](https://github.com/enigmaOfficial/enigma_learner/blob/master/Snipps/Picture2.png)
![Picture3](https://github.com/enigmaOfficial/enigma_learner/blob/master/Snipps/Picture3.png)
![Picture4](https://github.com/enigmaOfficial/enigma_learner/blob/master/Snipps/Picture4.png)

